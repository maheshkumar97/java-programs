import java.util.*;
class Prob2{
	public static void main(String... args){
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the array size for 2 arrays: ");
		int n = input.nextInt();
		int count=0;
		int[] array1 = new int[n];
		int[] array2 = new int[n];
		System.out.println("Enter the array1 elements");
		for(int i=0; i<n; i++){
			array1[i] = input.nextInt();
		}
		System.out.println("Enter the array2 elements");
		for(int i=0; i<n; i++){
			array2[i] = input.nextInt();
		}
		for( int i=0; i<n; i++)
			for(int j=0; j<n; j++){
				if(array1[i]==array2[j]){
					System.out.println("Common element: "+array1[i]);
					count++;
					break;
				}
			}
		System.out.println("common elements in both arrays count is: "+count);
	}
}