import java.util.*;
class Prob1{
	public static void main(String args[]){
		Scanner input = new Scanner(System.in);
		int sum = 0, count=0;
		System.out.print("Enter the array size: ");
		int n = input.nextInt();
		int[] array = new int[n];
		System.out.println("Enter the arrat elements");
		for(int i=0; i<n; i++){
			array[i] = input.nextInt();
		}
		for (int i = 1; i<n; i++){ 		  	  
          int counter=0; 	  
          for(int num =i; num>=1; num--){
             if(i%num==0){
             	counter = counter + 1;
             }
         }
         if (counter ==2){
         	System.out.println(array[i]);
         	sum = sum+array[i];
         	count++;
         }	
       }
       double avg = sum/count;
       System.out.println(avg);
	}
}